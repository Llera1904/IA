import re
import random
import longResponse

# Funcion para que responda el bot
def getResponse(userInput):
    splitMessage= re.split(r'\s|[,:;.?!-_]\s*', userInput.lower()) # Quita caracteres especiales y combierte a minusculas la entrada del usuario
    response= checkAllMessages(splitMessage)
    return response

# Funcion que determina la probabilidad de dar cada respuesta
def messageProbability(userMessage, recognizedWords, singleResponse= False, requiredWord= []):
    messageCertainty= 0
    hasRequiredWords= True

    for word in userMessage:
        if word in recognizedWords:
            messageCertainty+= 1

    percentage= float(messageCertainty) / float(len(recognizedWords))

    for word in requiredWord:
        if word not in userMessage:
            hasRequiredWords= False
            break

    if hasRequiredWords or singleResponse:
        return int(percentage * 100)
    else:
        return 0

# Checa cual de todas las respuestas posibles que hay, puede dar
def checkAllMessages(message):
        highestProb= {}

        def response(botResponse, listOfWords, singleResponse= False, requiredWords= []):
            nonlocal highestProb
            highestProb[botResponse]= messageProbability(message, listOfWords, singleResponse, requiredWords)

        # Respuestas posibles 
        response(longResponse.quienSoy, ['quien', 'que'], requiredWords= ['eres'])
        response(longResponse.comoEstas[random.randrange(3)], ['estas', 'va', 'vas', 'sientes'], requiredWords= ['como'])
        response(longResponse.saludo, ['hola', 'saludos', 'buenas', 'que', 'tal'], singleResponse= True)
        response(longResponse.despedida[random.randrange(4)], ['adios', 'hasta', 'luego', 'proxima', 'nos', 'vemos', 'me', 'voy'], singleResponse= True)
        response(longResponse.agradecimiento[random.randrange(3)], ['gracias', 'te', 'lo', 'agradezco', 'thanks'], singleResponse= True)
        response(longResponse.ayuda, ['ayuda'], singleResponse= True)

        response(longResponse.unidadesPrimero, ['primer', 'primero'], singleResponse= True)
        response(longResponse.unidadesSegundo, ['segundo'], singleResponse= True)
        response(longResponse.unidadesTercero, ['tercer', 'tercero'], singleResponse= True)
        response(longResponse.unidadesCuarto, ['cuarto'], singleResponse= True)
        response(longResponse.unidadesQuinto, ['quinto'], singleResponse= True)
        response(longResponse.unidadesSexto, ['sexto'], singleResponse= True)
        response(longResponse.unidadesSeptimo, ['septimo'], singleResponse= True)
        response(longResponse.unidadesOctavo, ['octavo'], singleResponse= True)
        response(longResponse.optativas, ['optativas'], singleResponse= True)

        response(longResponse.fundamentosProgramacion,['fundamentos','programacion'],singleResponse=True)
        response(longResponse.matematicasDiscretas,['matematicas','discretas'],singleResponse=True)
        response(longResponse.coe,['comunicacion','oral','escrita'],singleResponse=True)
        response(longResponse.mye,['mecanica','electromagnetismo'],singleResponse=True)
        response(longResponse.fundamentosEconomicos,['fundamentos','economicos'],singleResponse=True)
        response(longResponse.calculo,['calculo'],singleResponse=True)

        response(longResponse.algoritmosyED,['algoritmos','estructuras','datos'],singleResponse=True)
        response(longResponse.algebraLineal,['algebra','lineal'],singleResponse=True)
        response(longResponse.fundamentosDiseñoDigital,['fundamentos','diseño','digital'],singleResponse=True)
        response(longResponse.calculoMultivariable,['multivariable'],singleResponse=True)
        response(longResponse.ingenieriaEticaYSociedad,['ingenieria','etica','sociedad'],singleResponse=True)
        response(longResponse.finanzasEmpresariales,['finanzas','empresariales'],singleResponse=True)

        response(longResponse.analisisyDisenioDeAlgoritmos,['analisis','diseño'],singleResponse=True)
        response(longResponse.paradigmasProgra,['paradigmas','programacion'],singleResponse=True)
        response(longResponse.ecuacionesDiferenciales,['ecuaciones','diferenciales'],singleResponse=True)
        response(longResponse.basesDatos,['bases','datos'],singleResponse=True)
        response(longResponse.disenioSistemasDigitales,['diseño','sistemas','digitales'],singleResponse=True)
        response(longResponse.liderazgoPersonal,['liderazgo','personal'],singleResponse=True)

        response(longResponse.fundamentosIA,['fundamentos', 'inteligencia', 'artificial'], singleResponse=True)
        response(longResponse.probabilidad,['probabilidad'], singleResponse=True)
        response(longResponse.matematicasAvanzadas,['matematicas', 'avanzadas'], singleResponse=True)
        response(longResponse.tecnologiasWeb,['tecnologias', 'web'], singleResponse=True)
        response(longResponse.analisisSistemas,['analisis', 'sistemas'], singleResponse=True)
        response(longResponse.procesamientoDigitial,['procesamiento', 'imagenes'], singleResponse=True)
        response(longResponse.aprendizajeMaquina,['aprendizaje', 'maquina'] ,singleResponse=True)
        response(longResponse.visionArtificial,['vision', 'artificial'], singleResponse=True)
        response(longResponse.teoriaComputacional,['teoria', 'computacion'], singleResponse=True)
        response(longResponse.procesamientoDeSeniales,['procesamiento', 'señales'], singleResponse=True)
        response(longResponse.redesNeuronales,['redes', 'neuronales'], singleResponse=True)
        response(longResponse.reconocimientoVoz,['reconocimiento', 'voz'], singleResponse=True)

        response(longResponse.innovacion, ['innovacion', 'emprendimiento', 'tecnologico'], singleResponse= True)
        response(longResponse.propiedadIntelectual, ['propiedad', 'intelectual'], singleResponse= True)
        response(longResponse.lenguajeNatural, ['aplicaciones', 'lenguaje', 'natural'], singleResponse= True)
        response(longResponse.sistemasMultiagentes, ['sistemas', 'multiagentes'], singleResponse= True)
        response(longResponse.mineriaDatos, ['mineria', 'datos'], singleResponse= True)
        response(longResponse.bigData, ['big', 'data'], singleResponse= True)
        response(longResponse.temasSelectosIA, ['temas', 'selectos', 'inteligencia', 'artificial'], singleResponse= True)
        response(longResponse.computoParalelo, ['computo', 'paralelo'], singleResponse= True)
        response(longResponse.tecnicasProgramacionRobotsMoviles, ['tecnicas', 'programacion', 'robots', 'moviles'], singleResponse= True)
        response(longResponse.humanoMaquina, ['humano', 'maquina'], singleResponse= True)
        response(longResponse.aplicacionesSistemasMultiagentes, ['aplicaciones', 'sistemas', 'multiagentes'], singleResponse= True)
        response(longResponse.programacionDispositivosMoviles, ['programacion', 'dispositivos', 'moviles'], singleResponse= True)
        response(longResponse.sistemasEmbebidosIA, ['aplicaciones', 'inteligencia', 'artificial', 'sistemas', 'embebidos'], singleResponse= True)
        response(longResponse.algoritmosBioinspirados, ['topicos', 'selectos', 'algoritmos', 'bioinspirados'], singleResponse= True)

        # Encuentra la mejor respuesta
        bestMatch= max(highestProb, key= highestProb.get) # Encuentra el valor maximo en el diccionario y regresa la llave con el valor maximo
        #print(highestProb)

        return unknown(message) if highestProb[bestMatch] < 1 else bestMatch

# Funcion para cuando no se encontro una respuesta valida
def unknown(message):
    noRespondida= []
    noRespondida= message
    print(noRespondida)
    response= ['Puedes decirlo de nuevo?', 'No estoy seguro de lo quieres', 'búscalo en google a ver que tal'][random.randrange(3)]
    return response

#while True:
    #print("TITAN: " + getResponse(input('Yo: ')))