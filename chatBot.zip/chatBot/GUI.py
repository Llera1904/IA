from msilib.schema import File
from tkinter import *
from chatBot import getResponse

bgGray= "#ABB2B9"
bgColor= "#17202A"
textColor= "#EAECEE"

font= "Helvetica 14"
fontBold= "Helvetica 13 bold"

class ChatApplication:
    
    def __init__(self):
        self.chatbot= Tk()
        self.setupMainChatbot()
        
    def run(self):
        self.chatbot.mainloop()
        
    def setupMainChatbot(self):
        # Configuramos la ventana, le ponemos el títutlo, ancho, largo y fondo que lleva desde un inicio
        self.chatbot.iconbitmap('bot.ico')
        self.chatbot.title("Chatbot: Unidades de aprendizaje de IA")
        self.chatbot.resizable(width= False, height= False) # Si queremos que sea ajustable habilitamos con True
        self.chatbot.configure(width= 470, height= 550, bg= bgColor) # Configuaramos nuestra ventana 

        # head de la interfaz del chabot
        headChatbot= Label(self.chatbot, bg= bgColor, fg= textColor, text= "Bienvenido", font= fontBold, pady= 10)
        headChatbot.place(relwidth= 1)
        
        # linea de divicion
        line= Label(self.chatbot, width= 50, bg= bgGray)
        line.place(relwidth= 1, rely= 0.07, relheight= 0.012)
        
        # Ventana de texto
        self.textWindow= Text(self.chatbot, width= 20, height= 2, bg= bgColor, fg= textColor, font= font, padx= 5, pady= 5)
        self.textWindow.place(relheight= 0.745, relwidth= 1, rely= 0.08)
        self.textWindow.configure(cursor= "arrow", state= DISABLED)
        
        # boton 
        button= Label(self.chatbot, bg= bgGray, height= 80)
        button.place(relwidth= 1, rely= 0.825)
        
        # Caja donde entra el mensaje del usuario 
        self.msgEntry= Entry(button, bg= "#2C3E50", fg= textColor, font= font)
        self.msgEntry.place(relwidth= 0.74, relheight= 0.06, rely= 0.008, relx= 0.011)
        self.msgEntry.focus()
        self.msgEntry.bind("<Return>", self.send)
        
        # Configuaramos el evento de lo que hara el boton cuando sea apretado 
        sendButton= Button(button, text= "Enviar", font= fontBold, width= 20, bg= bgGray, command= lambda: self.send(None))
        sendButton.place(relx= 0.77, rely= 0.008, relheight= 0.06, relwidth= 0.22)
     
    # Función para enviar el mensaje junto con el nombre que llevará el usuario
    def send(self, event):
        msg= self.msgEntry.get()
        self.insertMessage(msg, "Yo")
        
    # Incertamos los mensajes en la ventana de texto     
    def insertMessage(self, msg, sender):
        if not msg:
          return
        
        self.msgEntry.delete(0, END)
        msg1= f"{sender}: {msg}\n\n"
        self.textWindow.configure(state= NORMAL)
        self.textWindow.insert(END, msg1)
        self.textWindow.configure(state= DISABLED)
        
        msg2= f"{'titIAn'}: {getResponse(msg)}\n\n" # Llamamos a nuestra funcion respuesta de nuestro chatbot
        self.textWindow.configure(state= NORMAL)
        self.textWindow.insert(END, msg2)
        self.textWindow.configure(state= DISABLED)
        
        self.textWindow.see(END)           
        
if __name__ == "__main__":
  app= ChatApplication()
  app.run()