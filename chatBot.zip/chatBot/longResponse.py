# Basicas
quienSoy= 'Soy titIAn! un bot programado para explicar las unidades de aprendizaje de ing en IA de la ESCOM puedes hacerme preguntas como:\n\n1. Que materias hay en "numero de semestre (primer semestre, segundo, tercero...)"\n2. Informacion sobre "Nombre de la materia"\n3. Que optativas hay'
comoEstas= ['Estoy bien', 'Podria estar mejor', 'No lose soy un programa']
saludo= 'Hola'
despedida= ['Hasta luego', 'Adios', '¿Te vas tan pronto?', 'NOOOOO NO ME DEJES... bueno ya vete']
agradecimiento= ['¿Te puedo ayudar con algo mas?', 'De nada', 'A la orden']
ayuda= 'Hola soy titIAn!\nPuedes hacerme preguntas como:\n\n1. Que materias hay en "numero de semestre (primer semestre, segundo, tercero...)"\n2. Informacion sobre "Nombre de la materia"\n3. Que optativas hay' 

# Materias en general
unidadesPrimero= 'Las unidades de aprendizaje para \nel primer semestre son: \n\tFundamentos de programacion\n\tMatemáticas discretas\n\tCálculo\n\tComunicacion oral y escrita\n\tFundamentos económicos\n\tMecánica y electromagnetismo'
unidadesSegundo= 'Las unidades de aprendizaje para \nel segundo semestre son: \n\tAlgoritmos y estructuras de datos\n\tFundamentos de diseño digital\n\tCálculo multivariable\n\tIngeniería etica y sociedad\n\tAlgebra lineal\n\tFinanzas empresariales'
unidadesTercero= 'Las unidades de aprendizaje para \nel tercer semestre son: \n\tAnálisis y diseño de algoritmos\n\tParadigmas de programacion\n\tEcuaciones diferenciales\n\tBases de datos\n\tDiseño de sistemas digitales\n\tLiderazgo personal'
unidadesCuarto= 'Las unidades de aprendizaje para \nel cuarto semestre son: \n\tFundamentos de inteligencia artificial\n\tProbabilidad y estadística\n\tMatemáticas avanzadas para la ingenieria\n\tTecnologías para el desarrollo de páginas web\n\tAnálisis y diseño de sistemas\n\tProcesamiento digital de imágenes'
unidadesQuinto= 'Las unidades de aprendizaje para \nel quinto semestre son: \n\tAprendizaje máquina\n\tVisión artificial\n\tTeoría computacional\n\tProcesamiento de señales\n\tAlgoritmos bioinspirados\n\tTecnologías de lenguaje natural'
unidadesSexto= 'Las unidades de aprendizaje para \nel sexto semestre son: \n\tCómputo paralelo\n\tRedes neuronales y aprendizaje profundo\n\t2 optativas\n\tMetodologías de la investigación\n\tDivulgación científica'
unidadesSeptimo= 'Las unidades de aprendizaje para \nel septimo semestre son: \n\tReconocimiento de voz\n\tTrabajo terminal 1\n\tFormulación y evaluación de proyectos informáticos\n\t2 Optativas'
unidadesOctavo= 'Las unidades de aprendizaje para \nel octavo semestre son: \n\tGestión empresarial\n\tTrabajo terminal 2\n\tEstancia profecional\n\tDesarrollo de habilidades sociales para la alta dirección'
optativas= 'Hay un total de 14 optativas:\n\nInnovación y emprendimiento tecnológico\nPropiedad intelectual\nAplicaciones de lenguaje natural\nSistemas multiagentes\nAplicaciones de sistemas multiagentes\nMinería de datos\nBig data\nTemas selectos de inteligencia artificial\nCómputo en paralelo\nTécnicas de programación para robots moviles\nInteracción humano - máquina\nProgramación de dispositivos móviles\nAplicaciones de inteligencia artificial en sistemas embebidos\nTópicos selectos de algoritmos bioinspirados'

# Info materias de primer semestre
fundamentosProgramacion= 'En la materia de fundamentos de Programacion cubres las bases necesarias para adentrarte un poco en el mundo de la programacion, el lenguaje que se utiliza es C y abarcas una gran cantidad de temas que son importantes para toda la carrera'
matematicasDiscretas= 'En esta materia ves varios temas que son aplicados en la logica de programacion, como pueden ser grafos, operaciones logicas, etc'
coe= 'Es una de las pocas materias de humanisticas que llevas. En ella aprendes algunas cosas importantes como pueden ser citar y poder mejorar tus habilidades sociales'
mye= 'Si en algun momento de la vocacional llevaste fisica puede que te suene familiar esto, aqui se centra mas en los temas de mecanica que se basa en el estudio y analisis del movimineot y reposo de los cuerpos. \nTambien se ve la rama del Electromagnetismo, la cual estudia y unifica los fenomenos electricos y magenticos'
fundamentosEconomicos= 'Se establecen conceptos basicos sobre economia, tambien abarca la parte de microeconomia y macroeconomia'
calculo= 'Abarca desde Calculo Diferencial hasta Calculo Integral. Se ven temas como limites, derivadas, maximos, minimos, integrales, area bajo la curva, volumenes de solidos en revolucion, etc'

# Info materias de segundo semestre
algoritmosyED= 'Es una introduccion a algunos de los algoritmos que existen, la utilidad de cada uno de ellos y su aplicacion. Ademas ves las estructuras de datos y aplicas uno de los temas mas importantes de Matematicas Discretas, que es Grafos'
algebraLineal= 'En esta materia ves temas como son matrices, solucion de ecuaciones mediante metodos que implican el uso de las mismas como Gauss Jordan. \nTambien se ve un poco el aspecto de la logica de conjuntos'
fundamentosDiseñoDigital= 'Aprendes lo basico sobre circuitos, conceptos y en algunos casos, se utiliza el lenguaje de programacion VHDL'
calculoMultivariable= 'Esto es una "continuacion" de Calculo de primer semestre, sin embargo aqui te centras mas en funciones en un plano tridimensional. \Es tanto Calculo Integral como Calculo Diferencial para 2 o mas variables'
ingenieriaEticaYSociedad= 'De igual forma que Comunicacion Oral y Escrita, sirve para mejorar tus habilidades de redaccion y sociales \nEn esta materia abarcas muchos temas importantes, y te hacen comprender como hemos llegado al mundo actual y la situacion de la IA en el aspecto etico'
finanzasEmpresariales= 'Aprendes a elaborar muchas cosas sobre el aspecto economico, como son el Estado de Situacion Financiera, PRI, VAN, Presupuesto Maestro, etc'

# Info materias de tercer semestre
analisisyDisenioDeAlgoritmos= 'Es una continuacion de "Algoritmos y Estructuras de Datos", aqui aprendes las complejidades de los algoritmos e incluso nuevos algoritmos que reducen el tiempo y costos de ejecucion'
paradigmasProgra= 'Es una materia en la que ves los tipos de Paradigmas de Programacion que hay, pero te centras en el Orientado a Objetos. \nSe usa el lenguaje de programacion Java y aprendes muchos conceptos y cosas relevantes de este paradigma'
ecuacionesDiferenciales= 'Abarca muchos temas para darle solucion a una ecuacion. Entre los mas destacables esta Integral de Fourier, Series de Fourier, Transformada de Laplace, Ecuacion de Euler y una infinidad mas'
basesDatos= 'Aprendes conceptos basicos sobre Bases de Datos, y te centras en las bases de datos relacionales (SQL). Utilizas el Sistema Gestor de Bases de Datos llamado MySQL y vas desde el DDL hasta el DCL'
disenioSistemasDigitales= 'Es una continuacion de Fundamentos de Disenio Digital, aqui ves mas a profundidad VHDL y la simulacion de circuitos mediante el mismo'
liderazgoPersonal= 'Es una de las materias donde te enseñan a crecer como persona, los tipos de liderazgo que existen y te hacen conocer el tuyo, para que de esta forma te puedas integrar de una mejor forma a un equipo de trabajo'

# Info materias de 4to a 6to semestre
fundamentosIA= 'La materia de fundamentos de inteligencia artificial establece tanto las bases históricas como académicas para el diseño de agentes inteligentes, como lo son los algoritmos de búsqueda, lógica de primer orden, lógica difusa, entre otros.'
probabilidad= 'Esta materia aporta al estudiante habilidades de análisis y aplicaciones de principios de probabilidad y de estadistica, con la finalidad de entender fenómenos aleatorios para el uso de validaciones en agentes.'
matematicasAvanzadas= 'Esta unidad es la continuación de ecuaciones diferenciales, su principal estudio son los números complejos y como estos se comportan dependiendo de distintas funciones.'
tecnologiasWeb= 'Durante esta materia el alumno aprenderá a desarrollar páginas web utilizando lenguajes como html, css y javascript, además de que también aprenderá distintos frameworks, ya sea para frontend o backend.'
analisisSistemas= 'En la materia de análisis y diseño de sistemas el alumno aprenderá las distintas metodologías (como la OMT, SCRUM, XP, entre otras) que se usan al momento de realizar un software, esto con la finalidad de dar calidad al programa que se esté haciendo.'
procesamientoDigitial= 'En esta unidad, el alumno aprenderá las características que conforman a las imágenes y a realizar algoritmos capáces de cambiar estas propiedades que poseen las imágenes (ya sea el nivel de gris, color o el  ruido).'
aprendizajeMaquina= 'Durante esta unidad de aprendizaje se aprenderá los principios teóricos y prácticos para implementar agentes inteligentes capaces de usar modelos de aprendizajes automáticos.'
visionArtificial= 'Esta materia es la continuación de procesamiento digital de imágenes, el alumno diseñará técnicas para el uso de la visión artificial en la resolución de problemas.'
teoriaComputacional= 'En teoria de la computación el alumno tendrá como objetivo aprender expresiones regulares y lenguaje, teoría de autómatas y conocimiento sobre la máquina de turing, con la finalidad de aplicarla en el desarrollo de agentes inteligentes.'
procesamientoDeSeniales= 'En la unidad de procesamiento de señales se enseñara a extraer y manipular información con la finalidad de que el alumno la utilice para desarrollar algortimos de aprendizaje máquina y de visión artificial.'
redesNeuronales= 'En la unidad de redes neuronales y aprendizaje profundo, el alumno utilizará conocimientos y algoritmos previamente vistos para el desarrollo de redes neuronales artificiales capaces de procesar información y también para desarrollar el aprendizaje profundo en los agentes inteligentes.'
reconocimientoVoz= 'En la unidad de reconocimiento de voz, el alumno utilizará diversos algoritmos y conocimientos previamente vistos para desarrollar programas inteligentes capaces de comprender la información que sale de forma sonora por medio de nuestra voz.'

# Info optativas
innovacion= 'En esta materia se impulsa el desarrollo de nuevos productos o servicios, de alta calidad, para atender un mercado dinámico y globalizado.'
propiedadIntelectual= 'Esta materia se relaciona con las creaciones.'
lenguajeNatural= 'En esta materia se ve la manera de comunicar las máquinas con las personas mediante el uso de lenguas naturales, como el español, el inglés o el chino y sus aplicaciones.'
sistemasMultiagentes= 'En esta materia se ves sistemas compuestos por múltiples agentes inteligentes que interactúan entre ellos.'
mineriaDatos= 'En esta materia se ve el proceso que intenta descubrir patrones en grandes volúmenes de conjuntos de datos.'
bigData= 'En esta materia se ven conjuntos de datos tan grandes y complejos que precisan de aplicaciones informáticas no tradicionales de procesamiento de datos para tratarlos adecuadamente.'
temasSelectosIA= 'En esta materia se ven los temas mas importantes en donde se aplica la IA.'
computoParalelo= 'En esta materia se ve una forma de cómputo en la que muchas instrucciones se ejecutan simultáneamente.'
tecnicasProgramacionRobotsMoviles= 'En esta materia se ven diferentes tecnicas de progrmacion para hacer robots moviles.'
humanoMaquina= 'Esta materia se trata de diseñar, evaluar e implementar sistemas informáticos interactivos para el uso humano, y estudiar los fenómenos relacionados más significativos.'
aplicacionesSistemasMultiagentes= 'En esta materia se ve donde se pueden aplicar los sistemas multiagentes.'
programacionDispositivosMoviles= 'En esta materia se ve el desarrollo para dispositivos moviles.'
sistemasEmbebidosIA= 'En esta materia se ve la plicacion de la IA en sistemas de computación basado en un microprocesador o un microcontrolador diseñado para realizar una o algunas pocas funciones dedicadas.'
algoritmosBioinspirados= 'En esta materia se ven los algoritmos de IA bioinspirados mas usados.'
