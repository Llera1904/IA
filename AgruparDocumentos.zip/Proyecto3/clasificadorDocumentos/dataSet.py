import pandas as pd
import pickle
import os

path= "recetas"
clasificaciones= ['bebidas', 'comidas', 'postres']
df= pd.DataFrame(columns= ['nombre', 'categoria', 'contenido'])
contenido= []
clasificacionCol= []
categoriaID= []
fileName= []

for clasificacion in clasificaciones:
   for root, dirs, files in os.walk(os.path.join(path, '{}'.format(clasificacion)), topdown=False):
      for name in files:
         filePath= os.path.join(root, name)
         fileContent= open(filePath, mode= 'r', encoding= 'UTF-8').read()
         contenido.append(fileContent)
         clasificacionCol.append(clasificacion)
         categoriaID.append(clasificaciones.index(clasificacion))
         fileName.append(name)

df["categoria"]= clasificacionCol
df["nombre"]= fileName
df["contenido"]= contenido
print(df)
print("\n")
print(df.loc[0]["contenido"])

# Exportamos el dataset
with open('dataFrames/dirtyData.pickle', 'wb') as output:
    pickle.dump(df, output)
with open('dataFrames/labels.pickle', 'wb') as output:
    pickle.dump(categoriaID, output)

