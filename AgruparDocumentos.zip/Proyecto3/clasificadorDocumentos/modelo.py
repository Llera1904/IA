from sklearn.cluster import KMeans
from sklearn.metrics import homogeneity_score
from sklearn.decomposition import PCA
from sklearn.cluster import AgglomerativeClustering
import matplotlib.pyplot as plt
import scipy.cluster.hierarchy as shc
import seaborn as sns
import pandas as pd
import pickle
import numpy as np

# Dataframe
with open("dataFrames/transformado.pickle", 'rb') as data:
    df= pickle.load(data)
with open("dataFrames/labels.pickle", 'rb') as data2:
    labelsTrue= pickle.load(data2)

# Buscamos el K optimo para el entrenamiento del K-means
distanciasCuadradas= [] # Para cada k
for k in range(1, 50):
    km= KMeans(n_clusters= k)
    km= km.fit(df.toarray())
    distanciasCuadradas.append(km.inertia_)

print(distanciasCuadradas)

sns.lineplot(x= range(1,31), y= distanciasCuadradas[0:30])
plt.show()

# Usamos el K optimo para el K-means
km= KMeans(n_clusters= 4)
km= km.fit(df.toarray())
labels= km.predict(df.toarray())
centroids= km.cluster_centers_
print(labels)
print("\n")

pca= PCA(n_components= 2)
datos= pca.fit_transform(df.toarray())
centroids= pca.transform(centroids)
print(datos)
print("\n")
print(centroids)
plt.scatter(datos[:, 0], datos[:, 1], c= labels)
plt.scatter(centroids[:, 0], centroids[:, 1], marker= '+', s= 150, color= 'red')
plt.show()

# varianza= []
# for n in range(1, 200):
#     pca= PCA(n_components= n)
#     pca.fit(df.toarray())
#     varianza.append(np.sum(pca.explained_variance_ratio_))

# plt.figure(figsize= (10, 5), dpi= 100)
# plt.plot(range(1, 200), varianza)
# plt.show()

print(homogeneity_score(labels_true= labelsTrue, labels_pred= labels))

# Jer
plt.figure(figsize= (10, 7))
plt.title("Dendrogramas")
dendrograma= shc.dendrogram(shc.linkage(df.toarray(), method= 'ward'))
plt.show()

algoritmo= AgglomerativeClustering(n_clusters= 4, affinity= 'euclidean', linkage= 'ward')
# Se entrena el algoritmo
algoritmo= algoritmo.fit(df.toarray())
labels= algoritmo.fit_predict(df.toarray())
print(labels)
print("\n")

pca= PCA(n_components= 2)
datos= pca.fit_transform(df.toarray())
print(datos)
plt.scatter(datos[:, 0], datos[:, 1], c= labels)
plt.show()

print(homogeneity_score(labels_true= labelsTrue, labels_pred= labels))

