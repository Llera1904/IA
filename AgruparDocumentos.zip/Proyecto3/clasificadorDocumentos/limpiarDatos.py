from sklearn.decomposition import PCA
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
import matplotlib.pyplot as plt
import pickle
import nltk

# Recuperamos la informacion
pathDf= "dataFrames/dirtyData.pickle"
with open(pathDf, 'rb') as data:
    df= pickle.load(data)

# print(df)
# print(df.loc[0]['contenido'])

# Limpiamos los datos
# \r, \n y "" (Saltos de linea y comillas)
df["contenido"]= df["contenido"].str.replace("\r", " ")
df["contenido"]= df["contenido"].str.replace("\n", " ")
df["contenido"]= df["contenido"].str.replace('"', "")
# Pasamos el texto a minusculas
df["contenido"]= df["contenido"].str.lower()
# Eliminacion de signos de puntuacion
signos= list("¿?:¡!.,;")
df["contenido"]= df["contenido"]
for signo in signos:
   df["contenido"]= df["contenido"].str.replace(signo, "")
# Eliminacion de pronombres posesivos (mío, mía, míos, mías, tuyo, tuya, tuyos, tuyas, suyo, suya, etc)
# df["contenido"]= df["contenido"].str.replace("'s", "")

# print(df)

# Lematizamos
nltk.download("punkt")
nltk.download("wordnet")
nltk.download('omw-1.4')
nltk.download('stopwords')
# Lematizador
wordNetLem= WordNetLemmatizer()

numeroFilas= len(df)
textosLematizados= []

for fila in range(0, numeroFilas):
   palabrasLematizadas= []

   # Guardamos el texto palabra por palabra para lematizar cada una
   texto= df.loc[fila]["contenido"]
   palabras= texto.split(" ")
   # print(palabras)

   # Lematizamos cada palabra (Verbos)
   for palabra in palabras:
      palabrasLematizadas.append(wordNetLem.lemmatize(palabra, pos= "v"))

   textoLematizado= " ".join(palabrasLematizadas)
   textosLematizados.append(textoLematizado)

# print(textosLematizados)

df["contenido"]= textosLematizados

# Quitamos las palabras que no nos dan mucha informacion
# Palabras vacias ('fuera', 'muy', ' tener', 'con', 'ellos', 'poseer', 'un', 'ser', 'algunos', 'para', 'hacer', etc)
# palabrasVacias= list(stopwords.words('english')) 
palabrasVacias= list(stopwords.words('spanish')) 
palabrasVacias.append('bbc')
# print(stop_words)

for palabraVacia in palabrasVacias:
   palabraVacia= r"\b" + palabraVacia + r"\b"
   df["contenido"]= df["contenido"].str.replace(palabraVacia, "")
   # print(palabraVacia)

df= df[["nombre", "categoria", "contenido"]]
print(df.loc[0]["contenido"])
print(df)

# Matriz TF-IDF
ngram_range= (1, 2)
min_df= 10
max_df= 1.0
max_features= 300
tfidf= TfidfVectorizer(encoding= 'utf-8',
                       ngram_range= ngram_range,
                       lowercase= False,
                       max_df= max_df,
                       min_df= min_df,
                       max_features= max_features,
                       norm= 'l2',
                       sublinear_tf= True)
transformado= tfidf.fit_transform(df["contenido"])

print(transformado)
# print(transformado.toarray())
print(tfidf.get_feature_names_out())

pca= PCA(n_components= 2)
datos= pca.fit_transform(transformado.toarray())
plt.scatter(datos[:, 0], datos[:, 1])
plt.show()

with open('dataFrames/transformado.pickle', 'wb') as output:
    pickle.dump(transformado, output)



