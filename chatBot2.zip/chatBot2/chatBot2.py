from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

entradaDelUsuario= "" # variable que contendrá lo que haya escrito el usuario

chatbot= ChatBot("TITAN") # Creamos una instancia del objeto ChatBot
# Entrenamos al chatbot
entrenador= ChatterBotCorpusTrainer(chatbot) 
#entrenador.train('chatterbot.corpus.spanish') 
entrenador.train('./PreguntasYRespuestas.yml') 

# Flujo de conversacion

print("chatbot: Hola, soy TITAN")
while entradaDelUsuario != "adios":
     entradaDelUsuario= input("Yo: ")
     respuesta= chatbot.get_response(entradaDelUsuario)
     print('TITAN: ', respuesta)